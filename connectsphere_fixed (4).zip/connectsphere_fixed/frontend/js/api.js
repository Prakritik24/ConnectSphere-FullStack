/* ============================================
   ConnectSphere API Client
   Connects to Express/MySQL backend.
   Falls back to localStorage if backend is
   unreachable (offline/demo mode).
   ============================================ */

const API_BASE = window.location.origin + '/api';

// ── Backend availability ───────────────────────────────────────
let _backendAvailable = null;
async function checkBackend() {
  if (_backendAvailable !== null) return _backendAvailable;
  try {
    const res = await fetch(API_BASE + '/health', {
      cache: 'no-store',
      signal: AbortSignal.timeout(6000),
    });
    const data = await res.json();
    _backendAvailable = res.ok && data.status === 'ok';
    console.log('[ConnectSphere] Backend reachable at', API_BASE, '| status:', data.status);
  } catch (err) {
    _backendAvailable = false;
    console.warn('[ConnectSphere] Backend NOT reachable at', API_BASE);
    console.warn('[ConnectSphere] Error:', err.message);
    console.warn('[ConnectSphere] Make sure backend is running: cd backend && npm start');
  }
  console.log('[ConnectSphere] Backend available:', _backendAvailable);
  return _backendAvailable;
}

// ── Token / Session helpers ────────────────────────────────────
function getToken()         { return localStorage.getItem('cs_token'); }
function setToken(t)        { localStorage.setItem('cs_token', t); }
function removeToken()      { localStorage.removeItem('cs_token'); }
function setCurrentUser(u)  { localStorage.setItem('cs_user', JSON.stringify(u)); }
function clearCurrentUser() { localStorage.removeItem('cs_user'); removeToken(); }
function getCurrentUser() {
  try { return JSON.parse(localStorage.getItem('cs_user')); } catch { return null; }
}
function isLoggedIn()         { return !!getToken() && !!getCurrentUser(); }
function getCurrentUserRole() { const u = getCurrentUser(); return u ? u.role : null; }

function authHeaders() {
  const h = { 'Content-Type': 'application/json' };
  const t = getToken();
  if (t) h['Authorization'] = 'Bearer ' + t;
  return h;
}

async function apiFetch(path, options) {
  options = options || {};
  const res = await fetch(API_BASE + path, {
    headers: authHeaders(),
    signal: AbortSignal.timeout(8000),
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

// ── LocalStorage fallback helpers ─────────────────────────────
function _lsGet(key)      { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } }
function _lsSet(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

function _initLS() {
  if (!_lsGet('cs_users')) {
    _lsSet('cs_users', [
      { id: 'user-1', name: 'John Student',    email: 'student@example.com',   password: 'password123', role: 'student' },
      { id: 'user-2', name: 'Alice Organizer', email: 'organizer@example.com', password: 'password123', role: 'organizer' },
      { id: 'user-3', name: 'Admin User',      email: 'admin@example.com',     password: 'password123', role: 'admin' },
    ]);
  }
  if (!_lsGet('cs_events')) {
    const future = d => { const dt = new Date(); dt.setDate(dt.getDate() + d); return dt.toISOString().split('T')[0]; };
    _lsSet('cs_events', [
      { id: 'event-1', name: 'Web Development Workshop',  description: 'Learn modern web development.', category: 'Workshop', date: future(7),  time: '14:00', venue: 'Engineering Building, Room 201', max_capacity: 30,  attendees: ['user-1'], organizer_name: 'Alice Organizer', organizer_id: 'user-2', type: 'In-person' },
      { id: 'event-2', name: 'Annual Cultural Festival',  description: 'Celebrate diversity with music and dance.', category: 'Cultural', date: future(14), time: '10:00', venue: 'Main Campus Grounds',             max_capacity: 500, attendees: [],         organizer_name: 'Alice Organizer', organizer_id: 'user-2', type: 'In-person' },
      { id: 'event-3', name: 'Basketball Tournament',     description: 'Inter-class basketball. All levels welcome.', category: 'Sports',   date: future(21), time: '16:00', venue: 'Sports Complex',                    max_capacity: 100, attendees: [],         organizer_name: 'Alice Organizer', organizer_id: 'user-2', type: 'In-person' },
      { id: 'event-4', name: 'Data Science Seminar',      description: 'Latest trends in data science and ML.',      category: 'Academic', date: future(10), time: '13:00', venue: 'Virtual Meeting Room',               max_capacity: 150, attendees: [],         organizer_name: 'Alice Organizer', organizer_id: 'user-2', type: 'Online'    },
    ]);
  }
}
_initLS();

// ── Auth ───────────────────────────────────────────────────────
async function registerUser(name, email, password, role) {
  if (!name || !email || !password || !role)
    return { success: false, message: 'All fields are required' };

  if (await checkBackend()) {
    try {
      const data = await apiFetch('/auth/register', {
        method: 'POST', body: JSON.stringify({ name, email, password, role }),
      });
      setToken(data.token);
      setCurrentUser(data.user);
      return { success: true, data: data.user };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }

  // Offline fallback
  const users = _lsGet('cs_users') || [];
  if (users.find(u => u.email === email))
    return { success: false, message: 'Email already registered' };
  const newUser = { id: 'user-' + Date.now(), name, email, password, role };
  users.push(newUser);
  _lsSet('cs_users', users);
  const { password: _, ...safe } = newUser;
  setCurrentUser(safe);
  return { success: true, data: safe };
}

async function loginUser(email, password) {
  if (!email || !password) return null;

  if (await checkBackend()) {
    try {
      const data = await apiFetch('/auth/login', {
        method: 'POST', body: JSON.stringify({ email, password }),
      });
      setToken(data.token);
      setCurrentUser(data.user);
      return data.user;
    } catch { return null; }
  }

  // Offline fallback
  const users = _lsGet('cs_users') || [];
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return null;
  const { password: _, ...safe } = user;
  setCurrentUser(safe);
  return safe;
}

function logoutUser() {
  removeToken();
  clearCurrentUser();
  window.location.href = 'index.html';
}

// ── Events ────────────────────────────────────────────────────
async function getAllEvents(filters) {
  filters = filters || {};
  const user = getCurrentUser();

  if (await checkBackend()) {
    try {
      const params = new URLSearchParams(filters).toString();
      const res = await fetch(API_BASE + '/events' + (params ? '?' + params : ''), {
        headers: Object.assign({}, authHeaders(), { 'x-user-id': user?.id || '' }),
        signal: AbortSignal.timeout(8000),
      });
      const data = await res.json();
      return (data.data || []).map(normalizeEvent);
    } catch {}
  }

  // Offline fallback
  let events = (_lsGet('cs_events') || []).map(e => ({
    ...e, is_registered: user ? (e.attendees || []).includes(user.id) : false,
    attendee_count: (e.attendees || []).length,
  }));
  if (filters.category) events = events.filter(e => e.category === filters.category);
  if (filters.type)     events = events.filter(e => e.type === filters.type);
  if (filters.search)   events = events.filter(e => e.name.toLowerCase().includes(filters.search.toLowerCase()));
  return events.map(normalizeEvent);
}

async function getUpcomingEvents(limit) {
  limit = limit || 10;
  if (await checkBackend()) {
    try {
      const res = await fetch(API_BASE + '/events/upcoming?limit=' + limit, {
        headers: authHeaders(), signal: AbortSignal.timeout(8000),
      });
      const data = await res.json();
      return (data.data || []).map(normalizeEvent);
    } catch {}
  }
  const now = new Date().toISOString().split('T')[0];
  return (_lsGet('cs_events') || [])
    .filter(e => e.date >= now)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, limit)
    .map(normalizeEvent);
}

async function getEventById(eventId) {
  const user = getCurrentUser();
  if (await checkBackend()) {
    try {
      const res = await fetch(API_BASE + '/events/' + eventId, {
        headers: Object.assign({}, authHeaders(), { 'x-user-id': user?.id || '' }),
        signal: AbortSignal.timeout(8000),
      });
      const data = await res.json();
      return data.data ? normalizeEvent(data.data) : null;
    } catch {}
  }
  const e = (_lsGet('cs_events') || []).find(ev => ev.id === eventId);
  if (!e) return null;
  return normalizeEvent({ ...e, is_registered: user ? (e.attendees || []).includes(user.id) : false });
}

async function createEvent(eventData) {
  const user = getCurrentUser();
  if (!user) return { success: false, message: 'Not logged in' };

  const payload = {
    name: eventData.name, description: eventData.description,
    category: eventData.category, date: eventData.date,
    time: eventData.time, venue: eventData.venue,
    max_capacity: eventData.maxCapacity, type: eventData.type || 'In-person',
  };

  if (await checkBackend()) {
    try {
      const data = await apiFetch('/events', { method: 'POST', body: JSON.stringify(payload) });
      return { success: true, data: data.data };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }

  // Offline fallback
  const events = _lsGet('cs_events') || [];
  const newEvent = {
    id: 'event-' + Date.now(), ...payload,
    max_capacity: payload.max_capacity || 100,
    organizer_id: user.id, organizer_name: user.name,
    attendees: [], attendee_count: 0,
  };
  events.push(newEvent);
  _lsSet('cs_events', events);
  return { success: true, data: normalizeEvent(newEvent) };
}

async function deleteEvent(eventId) {
  if (await checkBackend()) {
    try {
      await apiFetch('/events/' + eventId, { method: 'DELETE' });
      return { success: true };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }
  _lsSet('cs_events', (_lsGet('cs_events') || []).filter(e => e.id !== eventId));
  return { success: true };
}
var deleteEventFromSystem = deleteEvent;

async function registerUserForEvent(userId, eventId) {
  if (await checkBackend()) {
    try {
      await apiFetch('/events/' + eventId + '/register', { method: 'POST' });
      return { success: true };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }
  const user = getCurrentUser();
  const events = _lsGet('cs_events') || [];
  const idx = events.findIndex(e => e.id === eventId);
  if (idx === -1) return { success: false, message: 'Event not found' };
  const uid = user?.id || userId;
  if ((events[idx].attendees || []).includes(uid)) return { success: false, message: 'Already registered' };
  events[idx].attendees = [...(events[idx].attendees || []), uid];
  _lsSet('cs_events', events);
  return { success: true };
}

async function unregisterUserFromEvent(userId, eventId) {
  if (await checkBackend()) {
    try {
      await apiFetch('/events/' + eventId + '/register', { method: 'DELETE' });
      return { success: true };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }
  const user = getCurrentUser();
  const events = _lsGet('cs_events') || [];
  const idx = events.findIndex(e => e.id === eventId);
  if (idx === -1) return { success: false, message: 'Event not found' };
  const uid = user?.id || userId;
  events[idx].attendees = (events[idx].attendees || []).filter(id => id !== uid);
  _lsSet('cs_events', events);
  return { success: true };
}

// ── Users / Dashboard ─────────────────────────────────────────
async function getUserStats() {
  if (await checkBackend()) {
    try {
      const data = await apiFetch('/users/dashboard');
      return data.data;
    } catch {}
  }
  const user = getCurrentUser();
  if (!user) return null;
  const allEvents = _lsGet('cs_events') || [];
  const now = new Date().toISOString().split('T')[0];
  if (user.role === 'student') {
    const reg = allEvents.filter(e => (e.attendees || []).includes(user.id));
    return { registered: reg.length, upcoming: reg.filter(e => e.date >= now).length, past: reg.filter(e => e.date < now).length };
  }
  if (user.role === 'organizer') {
    const mine = allEvents.filter(e => e.organizer_id === user.id);
    return { created: mine.length, upcoming: mine.filter(e => e.date >= now).length, totalAttendees: mine.reduce((s, e) => s + (e.attendees || []).length, 0) };
  }
  if (user.role === 'admin') {
    const users = _lsGet('cs_users') || [];
    return { totalUsers: users.length, totalEvents: allEvents.length, totalRegs: allEvents.reduce((s, e) => s + (e.attendees || []).length, 0), upcoming: allEvents.filter(e => e.date >= now).length };
  }
  return null;
}

async function getUserEvents() {
  const user = getCurrentUser();
  if (await checkBackend()) {
    try {
      const data = await apiFetch('/users/my-events');
      return (data.data || []).map(normalizeEvent);
    } catch {}
  }
  if (!user) return [];
  const allEvents = _lsGet('cs_events') || [];
  let filtered;
  if (user.role === 'student')        filtered = allEvents.filter(e => (e.attendees || []).includes(user.id));
  else if (user.role === 'organizer') filtered = allEvents.filter(e => e.organizer_id === user.id);
  else                                filtered = allEvents;
  return filtered.map(e => normalizeEvent({ ...e, is_registered: (e.attendees || []).includes(user.id) }));
}

async function getAllUsers() {
  if (await checkBackend()) {
    try {
      const data = await apiFetch('/users');
      return data.data || [];
    } catch {}
  }
  return (_lsGet('cs_users') || []).map(({ password: _, ...u }) => u);
}

async function getStudentRegisteredEvents(userId) {
  return getUserEvents();
}

// ── Normalizer ─────────────────────────────────────────────────
function normalizeEvent(e) {
  return {
    id: e.id,
    name: e.name,
    description: e.description || '',
    category: e.category || '',
    date: e.date ? e.date.substring(0, 10) : '',
    time: e.time || 'TBA',
    venue: e.venue || '',
    maxCapacity: e.max_capacity || e.maxCapacity || 0,
    organizer: e.organizer_name || e.organizer || '',
    organizerId: e.organizer_id || e.organizerId || '',
    type: e.type || 'In-person',
    attendee_count: e.attendee_count || (Array.isArray(e.attendees) ? e.attendees.length : 0),
    is_registered: e.is_registered || false,
    attendees: Array.isArray(e.attendees)
      ? e.attendees.map(a => typeof a === 'object' ? a.id : a)
      : [],
  };
}

// ── Utilities ─────────────────────────────────────────────────
function formatDate(dateStr) {
  if (!dateStr) return 'TBA';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'long', day: 'numeric' });
}
function capitalizeRole(role) {
  if (!role) return '';
  return role.charAt(0).toUpperCase() + role.slice(1);
}
function finishLoading(contentId, duration, callback) {
  duration = duration || 500;
  const loader  = document.getElementById('loaderContainer');
  const content = document.getElementById(contentId);
  if (loader) {
    loader.style.transition = 'opacity ' + duration + 'ms';
    loader.style.opacity = '0';
    setTimeout(() => {
      loader.style.display = 'none';
      if (content) content.style.display = 'block';
      if (callback) callback();
    }, duration);
  } else {
    if (content) content.style.display = 'block';
    if (callback) callback();
  }
}

// ── Dark mode ─────────────────────────────────────────────────
function toggleDarkMode(event) {
  if (event) event.preventDefault();
  const isDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', isDark);
  const toggle = document.querySelector('.dark-mode-toggle');
  if (toggle) toggle.textContent = isDark ? '☀️' : '🌙';
}
(function () {
  const isDark = localStorage.getItem('darkMode') === 'true';
  if (isDark) document.body.classList.add('dark-mode');
  window.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('.dark-mode-toggle');
    if (toggle) toggle.textContent = isDark ? '☀️' : '🌙';
  });
})();
