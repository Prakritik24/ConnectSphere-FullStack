const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
});

// Tables are already created manually — just verify connection
async function initSchema() {
  const conn = await pool.getConnection();
  try {
    await conn.query('SELECT 1 FROM users LIMIT 1');
    await conn.query('SELECT 1 FROM events LIMIT 1');
    await conn.query('SELECT 1 FROM registrations LIMIT 1');
    console.log('✅ Database connection verified. Tables exist.');
  } catch (err) {
    console.error('❌ Database table check failed:', err.message);
    console.error('   Make sure you have run the SQL setup script to create tables.');
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { pool, initSchema };
