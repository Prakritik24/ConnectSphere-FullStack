const express  = require('express');
const { v4: uuidv4 } = require('uuid');
const { pool } = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// Helper: attach attendee count + registration status
async function enrichEvent(event, userId = null) {
  const [[{ count }]] = await pool.query(
    'SELECT COUNT(*) as count FROM registrations WHERE event_id = ?',
    [event.id]
  );
  event.attendee_count = count;

  if (userId) {
    const [regRows] = await pool.query(
      'SELECT id FROM registrations WHERE user_id = ? AND event_id = ?',
      [userId, event.id]
    );
    event.is_registered = regRows.length > 0;
  } else {
    event.is_registered = false;
  }
  return event;
}

// GET /api/events
router.get('/', async (req, res) => {
  const { search, category, type } = req.query;
  let sql = 'SELECT * FROM events WHERE 1=1';
  const params = [];

  if (search) {
    sql += ' AND (name LIKE ? OR description LIKE ? OR venue LIKE ?)';
    const like = `%${search}%`;
    params.push(like, like, like);
  }
  if (category) { sql += ' AND category = ?'; params.push(category); }
  if (type)     { sql += ' AND type = ?';     params.push(type); }
  sql += ' ORDER BY date ASC';

  try {
    const [rows] = await pool.query(sql, params);
    const userId  = req.headers['x-user-id'] || null;
    const enriched = await Promise.all(rows.map(e => enrichEvent(e, userId)));
    res.json({ success: true, data: enriched });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/events/upcoming
router.get('/upcoming', async (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  try {
    const [rows] = await pool.query(
      'SELECT * FROM events WHERE date >= CURDATE() ORDER BY date ASC LIMIT ?',
      [limit]
    );
    const enriched = await Promise.all(rows.map(e => enrichEvent(e)));
    res.json({ success: true, data: enriched });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/events/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Event not found' });

    const userId = req.headers['x-user-id'] || null;
    const event  = await enrichEvent(rows[0], userId);

    const [attendees] = await pool.query(
      `SELECT u.id, u.name, u.email, r.registered_at
       FROM registrations r JOIN users u ON r.user_id = u.id
       WHERE r.event_id = ?`,
      [req.params.id]
    );
    event.attendees = attendees;

    res.json({ success: true, data: event });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/events — create (organizer or admin)
router.post('/', authenticate, requireRole('organizer', 'admin'), async (req, res) => {
  const { name, description, category, date, time, venue, max_capacity, type } = req.body;

  if (!name || !description || !category || !date || !venue || !max_capacity) {
    return res.status(400).json({ message: 'All required fields must be filled' });
  }
  if (parseInt(max_capacity) < 1) {
    return res.status(400).json({ message: 'Capacity must be at least 1' });
  }

  try {
    const newId = uuidv4();
    await pool.query(
      `INSERT INTO events (id, name, description, category, date, time, venue, max_capacity, organizer_id, organizer_name, type)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [newId, name, description, category, date, time || null, venue,
       parseInt(max_capacity), req.user.id, req.user.name, type || 'In-person']
    );

    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [newId]);
    res.status(201).json({ success: true, data: rows[0] });
  } catch (err) {
    console.error('Create event error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// PUT /api/events/:id — update
router.put('/:id', authenticate, requireRole('organizer', 'admin'), async (req, res) => {
  const { name, description, category, date, time, venue, max_capacity, type } = req.body;

  try {
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Event not found' });

    const event = rows[0];
    if (req.user.role === 'organizer' && event.organizer_id !== req.user.id) {
      return res.status(403).json({ message: 'You can only edit your own events' });
    }

    await pool.query(
      `UPDATE events SET name=?, description=?, category=?, date=?, time=?, venue=?, max_capacity=?, type=?
       WHERE id=?`,
      [name || event.name, description || event.description, category || event.category,
       date || event.date, time !== undefined ? time : event.time, venue || event.venue,
       max_capacity || event.max_capacity, type || event.type, req.params.id]
    );

    const [updated] = await pool.query('SELECT * FROM events WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: updated[0] });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/events/:id
router.delete('/:id', authenticate, requireRole('organizer', 'admin'), async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Event not found' });

    if (req.user.role === 'organizer' && rows[0].organizer_id !== req.user.id) {
      return res.status(403).json({ message: 'You can only delete your own events' });
    }

    await pool.query('DELETE FROM events WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Event deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/events/:id/register
router.post('/:id/register', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Event not found' });

    const event = rows[0];
    const [[{ count }]] = await pool.query(
      'SELECT COUNT(*) as count FROM registrations WHERE event_id = ?', [event.id]
    );
    if (count >= event.max_capacity) {
      return res.status(409).json({ message: 'Event is full' });
    }

    await pool.query(
      'INSERT INTO registrations (user_id, event_id) VALUES (?, ?)',
      [req.user.id, req.params.id]
    );
    res.json({ success: true, message: 'Registered successfully' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Already registered for this event' });
    }
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/events/:id/register
router.delete('/:id/register', authenticate, async (req, res) => {
  try {
    const [result] = await pool.query(
      'DELETE FROM registrations WHERE user_id = ? AND event_id = ?',
      [req.user.id, req.params.id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Not registered for this event' });
    }
    res.json({ success: true, message: 'Unregistered successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
