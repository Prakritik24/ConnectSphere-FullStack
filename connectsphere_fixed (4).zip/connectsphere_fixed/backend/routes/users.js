const express = require('express');
const { pool } = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/users/dashboard — stats for current user
router.get('/dashboard', authenticate, async (req, res) => {
  const { id, role } = req.user;
  try {
    if (role === 'student') {
      const [[{ total }]] = await pool.query(
        'SELECT COUNT(*) as total FROM registrations WHERE user_id = ?', [id]
      );
      const [[{ upcoming }]] = await pool.query(
        `SELECT COUNT(*) as upcoming FROM registrations r
         JOIN events e ON r.event_id = e.id
         WHERE r.user_id = ? AND e.date >= CURDATE()`, [id]
      );
      const [[{ past }]] = await pool.query(
        `SELECT COUNT(*) as past FROM registrations r
         JOIN events e ON r.event_id = e.id
         WHERE r.user_id = ? AND e.date < CURDATE()`, [id]
      );
      return res.json({ success: true, data: { registered: total, upcoming, past } });
    }

    if (role === 'organizer') {
      const [[{ created }]] = await pool.query(
        'SELECT COUNT(*) as created FROM events WHERE organizer_id = ?', [id]
      );
      const [[{ upcoming }]] = await pool.query(
        'SELECT COUNT(*) as upcoming FROM events WHERE organizer_id = ? AND date >= CURDATE()', [id]
      );
      const [[{ totalAttendees }]] = await pool.query(
        `SELECT COUNT(*) as totalAttendees FROM registrations r
         JOIN events e ON r.event_id = e.id WHERE e.organizer_id = ?`, [id]
      );
      return res.json({ success: true, data: { created, upcoming, totalAttendees } });
    }

    if (role === 'admin') {
      const [[{ totalUsers }]]  = await pool.query('SELECT COUNT(*) as totalUsers FROM users');
      const [[{ totalEvents }]] = await pool.query('SELECT COUNT(*) as totalEvents FROM events');
      const [[{ totalRegs }]]   = await pool.query('SELECT COUNT(*) as totalRegs FROM registrations');
      const [[{ upcoming }]]    = await pool.query(
        'SELECT COUNT(*) as upcoming FROM events WHERE date >= CURDATE()'
      );
      return res.json({ success: true, data: { totalUsers, totalEvents, totalRegs, upcoming } });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/users/my-events — events relevant to current user
router.get('/my-events', authenticate, async (req, res) => {
  const { id, role } = req.user;
  try {
    let rows;
    if (role === 'student') {
      [rows] = await pool.query(
        `SELECT e.* FROM events e
         JOIN registrations r ON e.id = r.event_id
         WHERE r.user_id = ? ORDER BY e.date ASC`, [id]
      );
    } else if (role === 'organizer') {
      [rows] = await pool.query(
        'SELECT * FROM events WHERE organizer_id = ? ORDER BY date ASC', [id]
      );
    } else {
      [rows] = await pool.query('SELECT * FROM events ORDER BY date ASC');
    }
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/users — all users (admin only)
router.get('/', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC'
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/users/:id
router.get('/:id', authenticate, async (req, res) => {
  if (req.user.id !== req.params.id && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  try {
    const [rows] = await pool.query(
      'SELECT id, name, email, role, created_at FROM users WHERE id = ?',
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'User not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
